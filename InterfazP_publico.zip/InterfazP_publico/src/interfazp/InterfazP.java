/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfazp;

import Ventanas.Logn;

/**
 *
 * @author 59399
 */
public class InterfazP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Logn lg=new Logn();
lg.setVisible(true);
lg.setLocationRelativeTo(null);

    }
    
}
