Carpeta de datos generados en ejecución. Se deja vacía para publicar el proyecto sin datos personales.
