/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mejora;

import PanelPrincipal.MenuV;
import PanelPrincipal.registroauto;

/**
 *
 * @author 59399
 */
public class Mejora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        registroauto au=new registroauto();
       au.setVisible(true);
        au.setLocationRelativeTo(null);
      
  

    }
    
}
