package PanelPrincipal;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import javax.swing.JOptionPane;

public class Ingresopin extends javax.swing.JFrame {

    private registroauto registro;

    public Ingresopin() {
        initComponents();
        this.registro = new registroauto();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextFieldingresopin = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButtonregresar = new javax.swing.JButton();
        jButtonconfirmar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextFieldingresopin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldingresopinActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldingresopin, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 200, -1));

        jLabel1.setText("Ingrese pin para ingresar vehiculo");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, -1, -1));

        jButtonregresar.setText("Regresar");
        jButtonregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonregresarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

        jButtonconfirmar.setText("Confirmar");
        jButtonconfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonconfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonconfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonregresarActionPerformed
     Cliente cli = new Cliente(registro);
        this.setVisible(false);
        cli.setVisible(true);
            }//GEN-LAST:event_jButtonregresarActionPerformed

    




    private void jButtonconfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonconfirmarActionPerformed
        String pinIngresado = jTextFieldingresopin.getText().trim();

    if (pinIngresado.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingrese un PIN.");
        return;
    }

    File carpeta = new File("archivo");
    boolean encontrado = false;

    if (carpeta.exists()) {
        for (File archivo : carpeta.listFiles((dir, name) -> name.endsWith(".txt"))) {
            try (Scanner scanner = new Scanner(archivo)) {
                String pin = "", tipo = "", cedula = "", estado = "";
                LocalDate fechaIngreso = null;
                int diasPermitidos = 0;

                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.startsWith("Pin: ")) pin = linea.substring(5).trim();
                    else if (linea.startsWith("Vehiculo: ")) tipo = linea.substring(10).trim();
                    else if (linea.startsWith("Cedula: ")) cedula = linea.substring(8).trim();
                    else if (linea.startsWith("Estado: ")) estado = linea.substring(8).trim();
                    else if (linea.startsWith("FechaIngreso: ")) fechaIngreso = LocalDate.parse(linea.substring(14).trim());
                    else if (linea.startsWith("Dias: ")) diasPermitidos = Integer.parseInt(linea.substring(6).trim());
                    else if (linea.startsWith("DiasPermitidos: ")) diasPermitidos = Integer.parseInt(linea.substring(16).trim());
                }

                if (pin.equals(pinIngresado)) {
                    encontrado = true;

                    if (estado.equalsIgnoreCase("Activo")) {
                        JOptionPane.showMessageDialog(this, "El vehículo ya se encuentra en el estacionamiento.");
                        return;
                    }

                    if (estado.equalsIgnoreCase("SALIDA")) {
                        if (fechaIngreso != null && diasPermitidos > 0) {
                            LocalDate hoy = LocalDate.now();
                            LocalDate fechaLimite = fechaIngreso.plusDays(diasPermitidos);

                            if (hoy.isAfter(fechaLimite)) {
                                long diasVencidos = java.time.temporal.ChronoUnit.DAYS.between(fechaLimite, hoy);
                                double monto = diasVencidos * 1.5;

                                int opcion = JOptionPane.showConfirmDialog(this,
                                        "El tiempo de estacionamiento ha vencido.\n¿Desea volver a ingresar?\nDebe pagar: $" + monto,
                                        "Plazo Vencido", JOptionPane.YES_NO_OPTION);

                                if (opcion == JOptionPane.YES_OPTION) {
                                    String nuevoDiasStr = JOptionPane.showInputDialog(this, "Ingrese nueva cantidad de días para el vehículo:");
                                    try {
                                        int nuevosDias = Integer.parseInt(nuevoDiasStr);
                                        restaurarEstadoActivo(archivo, nuevosDias);
                                        JOptionPane.showMessageDialog(this, "Reingreso exitoso. Estado actualizado a ACTIVO.");
                                        registro.actualizarColoresBotones();
                                        this.dispose();
                                        return;
                                    } catch (NumberFormatException e) {
                                        JOptionPane.showMessageDialog(this, "Entrada inválida para días. Operación cancelada.");
                                        return;
                                    }
                                } else {
                                    double total = (diasPermitidos + diasVencidos) * 1.50; //precio
                                    archivo.delete();
                                    JOptionPane.showMessageDialog(this, "Archivo eliminado. Total a pagar: $" + total);
                                    registro.actualizarColoresBotones();
                                    this.dispose();
                                    return;
                                }
                            } else {
                           restaurarEstadoActivo(archivo, diasPermitidos);
                        JOptionPane.showMessageDialog(this, "Reingreso exitoso. Estado actualizado a ACTIVO.");
                           registro.actualizarColoresBotones();
                               abrirVentanaPorVehiculo(tipo);  // 👈 Abre el menú para volver a elegir puesto
                          return;
                           }
                        }
                    }

                    if (estado.equalsIgnoreCase("Inactivo")) {
                        abrirVentanaPorVehiculo(tipo);
                        return;
                    }
                }

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al leer archivo: " + e.getMessage());
                return;
            }
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(this, "PIN no encontrado.");
    }
    }

    private void abrirVentanaPorVehiculo(String tipo) {
        switch (tipo) {
            case "Auto" -> new Automovil(registro, tipo).setVisible(true);
            case "Camioneta" -> new Camioneta(registro, tipo).setVisible(true);
            case "Moto", "Bicicleta" -> new MotoBici(registro, tipo).setVisible(true);
            default -> JOptionPane.showMessageDialog(this, "Tipo de vehículo desconocido: " + tipo);
        }
        this.dispose();
    }

    private void restaurarEstadoActivo(File archivo, int nuevosDias) {
        try {
            List<String> nuevasLineas = new ArrayList<>();
            LocalDate nuevaFecha = LocalDate.now();
            try (Scanner scanner = new Scanner(archivo)) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.startsWith("Estado: ")) {
                        nuevasLineas.add("Estado: Activo");
                    } else if (linea.startsWith("FechaIngreso: ")) {
                        nuevasLineas.add("FechaIngreso: " + nuevaFecha);
                    } else if (linea.startsWith("Dias: ") || linea.startsWith("DiasPermitidos: ")) {
                        nuevasLineas.add("Dias: " + nuevosDias);
                    } else {
                        nuevasLineas.add(linea);
                    }
                }
            }

            try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
                for (String linea : nuevasLineas) {
                    writer.println(linea);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar estado: " + e.getMessage());
        }
    
    }//GEN-LAST:event_jButtonconfirmarActionPerformed

       


    
    private void jTextFieldingresopinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldingresopinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldingresopinActionPerformed

   
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingresopin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingresopin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingresopin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingresopin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingresopin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonconfirmar;
    private javax.swing.JButton jButtonregresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFieldingresopin;
    // End of variables declaration//GEN-END:variables
}
