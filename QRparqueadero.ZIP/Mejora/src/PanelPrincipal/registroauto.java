package PanelPrincipal;

import PanelPrincipal.CamaraQR;
import PanelPrincipal.CodigoQr;
import PanelPrincipal.MenuV;
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.time.LocalDate;
import javax.swing.text.*;

public class registroauto extends javax.swing.JFrame {

    static Set<String> cedulasRegistradas = new HashSet<>();
    static Set<String> placasRegistradas = new HashSet<>();
    static Set<String> pinesUsados = new HashSet<>();

    private final Map<String, String> puestosOcupados = new HashMap<>();
    private final Map<String, LocalDate> fechasIngreso = new HashMap<>();
    private final Map<String, Integer> diasPermitidos = new HashMap<>();
    private final Map<String, LocalDate> puestosReservados = new HashMap<>();
    private final Set<String> puestosSalientes = new HashSet<>();
    public Map<String, JButton> mapaBotones = new HashMap<>();

    private String puestoSeleccionado = "Seleccionar";
    private String tipoVehiculo = "No seleccionado";
    private FiltroPlacaPorVehiculo filtroPlaca;

    public registroauto() {
        initComponents();
        setLocationRelativeTo(null);
        cargarPuestosOcupados();
        cargarDatosExistentes();
        ((AbstractDocument) txtcedula.getDocument()).setDocumentFilter(new SoloNumerosLimitado(10));
        ((AbstractDocument) txttelefono.getDocument()).setDocumentFilter(new SoloNumerosLimitado(10));
        ((AbstractDocument) txtnombre.getDocument()).setDocumentFilter(new SoloLetrasConEspacios());
        ((AbstractDocument) txtapellido.getDocument()).setDocumentFilter(new SoloLetrasConEspacios());

        filtroPlaca = new FiltroPlacaPorVehiculo(tipoVehiculo);
        ((AbstractDocument) txtplaca.getDocument()).setDocumentFilter(filtroPlaca);
    }

   public void procesarEntradaSalida(String textoQR, CamaraQR.Modo modo) {
    String cedula = "";
    String puesto = "";

    for (String linea : textoQR.split("\n")) {
        if (linea.startsWith("Cédula: ")) {
            cedula = linea.substring(8).trim();
        } else if (linea.startsWith("Puesto: ")) {
            puesto = linea.substring(8).trim();
        }
    }

    if (cedula.isEmpty() || puesto.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No se pudo extraer cédula o puesto desde el QR.");
        return;
    }

    File carpeta = new File("archivo");
    File archivoCliente = null;

    if (carpeta.exists()) {
        for (File archivo : carpeta.listFiles()) {
            if (archivo.getName().endsWith(cedula + ".txt")) {
                archivoCliente = archivo;
                break;
            }
        }
    }

  if (archivoCliente == null || !archivoCliente.exists()) {
    if (modo == CamaraQR.Modo.SALIDA) {
        JOptionPane.showMessageDialog(null, "🚫 Este vehículo ya fue retirado definitivamente. No hay datos.");
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró archivo para la cédula: " + cedula);
    }
    return;
}

    if (modo == CamaraQR.Modo.ENTRADA) {
        // Leer estado actual
        String estado = "";
        try (Scanner scanner = new Scanner(archivoCliente)) {
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.startsWith("Estado: ")) {
                    estado = linea.substring(8).trim();
                    break;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer el estado: " + e.getMessage());
            return;
        }

        if (estado.equalsIgnoreCase("Activo")) {
            JOptionPane.showMessageDialog(null, "El vehículo ya se encuentra en el estacionamiento.");
            return;
        }

        if (estado.equalsIgnoreCase("SALIDA")) {
            // Cambiar estado a ACTIVO
            try {
                List<String> nuevasLineas = new ArrayList<>();
                try (Scanner scanner = new Scanner(archivoCliente)) {
                    while (scanner.hasNextLine()) {
                        String linea = scanner.nextLine();
                        if (linea.startsWith("Estado: ")) {
                            nuevasLineas.add("Estado: Activo");
                        } else {
                            nuevasLineas.add(linea);
                        }
                    }
                }
                try (PrintWriter writer = new PrintWriter(new FileWriter(archivoCliente))) {
                    for (String linea : nuevasLineas) {
                        writer.println(linea);
                    }
                }
                registrarOcupacion(puesto, "Desconocido");
                puestosSalientes.remove(puesto);
                JOptionPane.showMessageDialog(null, "Reingreso exitoso. Estado actualizado a ACTIVO.");
                actualizarColoresBotones();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al actualizar estado: " + e.getMessage());
            }
            return;
        }

        if (estado.equalsIgnoreCase("Inactivo")) {
            JOptionPane.showMessageDialog(null, "Este vehículo no puede reingresar. Estado: INACTIVO.");
            return;
        }
    }

    if (modo == CamaraQR.Modo.SALIDA) {
        List<String> lineas = new ArrayList<>();
        String estadoActual = "", fechaIngresoStr = "";
        int diasPermitidos = 0;

        try (Scanner scanner = new Scanner(archivoCliente)) {
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.startsWith("Estado: ")) estadoActual = linea.substring(8).trim();
                if (linea.startsWith("FechaIngreso: ")) fechaIngresoStr = linea.substring(14).trim();
                if (linea.startsWith("Dias: ")) diasPermitidos = Integer.parseInt(linea.substring(6).trim());
                lineas.add(linea);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer archivo: " + e.getMessage());
            return;
        }

        if (!estadoActual.equalsIgnoreCase("Activo")) {
            JOptionPane.showMessageDialog(null, "Este vehículo no está en estado ACTIVO. No se puede retirar.");
            return;
        }

        String[] opciones = {"Temporalmente", "Definitivamente"};
        int eleccion = JOptionPane.showOptionDialog(null,
                "¿Desea retirar el vehículo temporal o definitivamente?",
                "Confirmar Retiro",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]);

        if (eleccion == 0 || eleccion == 1) {
    String nuevoEstado = (eleccion == 0) ? "SALIDA" : "Inactivo";
    boolean mostrarMonto = false;
    double monto = 0.0;

    if (!fechaIngresoStr.isEmpty() && diasPermitidos > 0) {
        try {
            LocalDate fechaIngreso = LocalDate.parse(fechaIngresoStr);
            int diasPasados = (int) java.time.temporal.ChronoUnit.DAYS.between(fechaIngreso, LocalDate.now());

            if (nuevoEstado.equals("Inactivo") || diasPasados >= diasPermitidos) {
                monto = diasPasados * 1.50;
                mostrarMonto = true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al procesar fecha de ingreso.");
        }
    }

    if (nuevoEstado.equals("Inactivo")) {
        // Mostrar mensaje antes de borrar
        String mensaje = "✅ Vehículo retirado definitivamente. Archivo eliminado.";
        if (mostrarMonto) {
            mensaje += "\nTotal a pagar: $" + String.format("%.2f", monto);
        }
        JOptionPane.showMessageDialog(null, mensaje);

        // Eliminar archivo
        if (archivoCliente.delete()) {
    File imagenQR = new File("imagen/" + cedula + ".png");
    if (imagenQR.exists()) {
        try {
            System.gc(); // fuerza al recolector de basura a liberar recursos
            Thread.sleep(100); // da tiempo al sistema para soltar la imagen
            if (imagenQR.delete()) {
                System.out.println("✅ Imagen QR eliminada correctamente.");
            } else {
                System.out.println("⚠️ No se pudo eliminar la imagen QR.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar imagen QR: " + ex.getMessage());
        }
    }

    puestosOcupados.remove(puesto);
    puestosSalientes.add(puesto);
} else {
    JOptionPane.showMessageDialog(null, "⚠️ Vehículo retirado, pero no se pudo eliminar el archivo.");
}

    } else {
        // Salida temporal: actualizar archivo con nuevo estado
        try (PrintWriter writer = new PrintWriter(new FileWriter(archivoCliente))) {
            for (String linea : lineas) {
                if (linea.startsWith("Estado: ")) {
                    writer.println("Estado: " + nuevoEstado);
                } else {
                    writer.println(linea);
                }
            }

            if (mostrarMonto) {
                writer.println("MontoPagado: $" + String.format("%.2f", monto));
            }

            String mensaje = "Vehículo marcado como 'SALIDA' correctamente.";
            if (mostrarMonto) {
                mensaje += "\nTotal a pagar: $" + String.format("%.2f", monto);
            }

            JOptionPane.showMessageDialog(null, mensaje);
            puestosOcupados.remove(puesto);
            puestosSalientes.add(puesto);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el archivo: " + e.getMessage());
        }
    }

    actualizarColoresBotones();
}
    }
  }


   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabelcedula = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtapellido = new javax.swing.JTextField();
        jLabelvehiculo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtcedula = new javax.swing.JTextField();
        jLabelnombre = new javax.swing.JLabel();
        txttelefono = new javax.swing.JTextField();
        jLabeltelefono = new javax.swing.JLabel();
        jLabelapellido = new javax.swing.JLabel();
        txtplaca = new javax.swing.JTextField();
        jLabelseleccionar = new javax.swing.JLabel();
        jButtonregistro = new javax.swing.JButton();
        btRegresar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        labelpin = new javax.swing.JLabel();
        jLabeldias = new javax.swing.JLabel();
        jTextFielddias = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtcorreo = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("REGISTRO DE ESTACIONAMIENTO");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(247, 247, 247)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(256, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabelcedula.setText("Cedula");
        jPanel1.add(jLabelcedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });
        jPanel1.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 267, -1));
        jPanel1.add(txtapellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 267, -1));

        jLabelvehiculo.setText("Vehiculo");
        jPanel1.add(jLabelvehiculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, 20));

        jLabel4.setText("Placa");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        txtcedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcedulaActionPerformed(evt);
            }
        });
        jPanel1.add(txtcedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 267, -1));

        jLabelnombre.setText("Nombres");
        jPanel1.add(jLabelnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 70, -1));
        jPanel1.add(txttelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 270, -1));

        jLabeltelefono.setText("Telefono");
        jPanel1.add(jLabeltelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, -1, -1));

        jLabelapellido.setText("Apellidos");
        jPanel1.add(jLabelapellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        txtplaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtplacaActionPerformed(evt);
            }
        });
        jPanel1.add(txtplaca, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 310, 268, -1));

        jLabelseleccionar.setText("Seleccionar");
        jLabelseleccionar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelseleccionar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelseleccionarMouseClicked(evt);
            }
        });
        jPanel1.add(jLabelseleccionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, -1, -1));

        jButtonregistro.setText("Siguiente");
        jButtonregistro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonregistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonregistroActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 470, 120, 30));

        btRegresar.setText("Regresar");
        btRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 100, 30));

        jLabel2.setText("Pin");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, -1, -1));

        labelpin.setText("clave");
        jPanel1.add(labelpin, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 430, -1, -1));

        jLabeldias.setText("Dias");
        jPanel1.add(jLabeldias, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));

        jTextFielddias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFielddiasActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFielddias, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 350, 110, -1));

        jLabel3.setText("Correo");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, -1, -1));
        jPanel1.add(txtcorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 390, 270, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 748, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed

    private void jLabelseleccionarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelseleccionarMouseClicked
     MenuV menu = new MenuV(this, null);        
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        
    }//GEN-LAST:event_jLabelseleccionarMouseClicked

 private void restaurarEstadoActivo(File archivo, int nuevosDias) {
        try {
            List<String> nuevasLineas = new ArrayList<>();
            LocalDate nuevaFecha = LocalDate.now();

            try (Scanner scanner = new Scanner(archivo)) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.startsWith("Estado: ")) {
                        nuevasLineas.add("Estado: Activo");
                    } else if (linea.startsWith("FechaIngreso: ")) {
                        nuevasLineas.add("FechaIngreso: " + nuevaFecha);
                    } else if (linea.startsWith("Dias: ")) {
                        nuevasLineas.add("Dias: " + nuevosDias);
                    } else {
                        nuevasLineas.add(linea);
                    }
                }
            }

            try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
                for (String linea : nuevasLineas) {
                    writer.println(linea);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar estado: " + e.getMessage());
        }
    }

    private void eliminarArchivo(File archivo) {
        if (archivo.delete()) {
            JOptionPane.showMessageDialog(this, "Archivo eliminado correctamente. Registro finalizado.");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar el archivo.");
        }
    }

    private void jButtonregistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonregistroActionPerformed
        String nombre = txtnombre.getText().trim();
    String apellido = txtapellido.getText().trim();
    String cedula = txtcedula.getText().trim();
    String telefono = txttelefono.getText().trim();
    String placa = txtplaca.getText().trim().toUpperCase();
    String diasTexto = jTextFielddias.getText().trim();
    String correo=txtcorreo.getText().trim();
    if (nombre.isEmpty() || apellido.isEmpty() || cedula.isEmpty() || telefono.isEmpty()
            || tipoVehiculo.equals("No seleccionado") || puestoSeleccionado.equals("Seleccionar")|| correo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, llena todos los campos antes de registrar.");
        return;
    }

    if (!cedula.matches("\\d{10}")) {
        JOptionPane.showMessageDialog(this, "La cédula debe contener exactamente 10 dígitos numéricos.");
        return;
    }

    if (!telefono.matches("\\d{10}")) {
        JOptionPane.showMessageDialog(this, "El teléfono debe contener exactamente 10 dígitos numéricos.");
        return;
    }

    if (!diasTexto.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "Debe ingresar una cantidad válida de días.");
        return;
    }

    int diasPermitidosInt = Integer.parseInt(diasTexto);
    LocalDate fechaHoy = LocalDate.now();
    fechasIngreso.put(puestoSeleccionado, fechaHoy);
    diasPermitidos.put(puestoSeleccionado, diasPermitidosInt);

    File archivo = new File("archivo/" + nombre + "_" + cedula + ".txt");

    // Verificar si el archivo ya existe
    if (archivo.exists()) {
        try (Scanner scanner = new Scanner(archivo)) {
            String estado = "";
            LocalDate fechaIngreso = null;
            int diasAnteriores = 0;

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.startsWith("Estado: ")) estado = linea.substring(8).trim();
                if (linea.startsWith("FechaIngreso: ")) fechaIngreso = LocalDate.parse(linea.substring(14).trim());
                if (linea.startsWith("Dias: ")) diasAnteriores = Integer.parseInt(linea.substring(6).trim());
            }

            if (estado.equals("SALIDA")) {
                LocalDate fechaLimite = fechaIngreso.plusDays(diasAnteriores);
                long diasVencidos = java.time.temporal.ChronoUnit.DAYS.between(fechaLimite, fechaHoy);

                if (diasVencidos > 0) {
                    int opcion = JOptionPane.showConfirmDialog(this,
                        "El tiempo ha vencido hace " + diasVencidos + " días.\n¿Desea volver a ingresar?\nDebe pagar $" + (diasVencidos * 1.5),
                        "Tiempo vencido",
                        JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        String nuevoTexto = JOptionPane.showInputDialog(this, "Ingrese la nueva cantidad de días:");
                        if (nuevoTexto == null || !nuevoTexto.matches("\\d+")) {
                            JOptionPane.showMessageDialog(this, "Cantidad de días inválida.");
                            return;
                        }
                        int nuevosDias = Integer.parseInt(nuevoTexto);
                        restaurarEstadoActivo(archivo, nuevosDias);
                        JOptionPane.showMessageDialog(this, "Archivo actualizado. Puede volver a ingresar.");
                        this.dispose();
                        return;
                    } else {
                        double precioTotal = (diasAnteriores + diasVencidos) * 1.5;
                        JOptionPane.showMessageDialog(this, "Debe pagar $" + precioTotal + "\nSe eliminará el registro.");
                        eliminarArchivo(archivo);
                        this.dispose();
                        return;
                    }
                } else {
                    // Todavía puede reingresar sin pagar extra
                    restaurarEstadoActivo(archivo, diasPermitidosInt);
                    JOptionPane.showMessageDialog(this, "Registro restaurado. Puede volver a ingresar.");
                    this.dispose();
                    return;
                }
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer archivo existente: " + ex.getMessage());
            return;
        }
    }

    if (cedulasRegistradas.contains(cedula)) {
        JOptionPane.showMessageDialog(this, "Esta cédula ya fue registrada.");
        return;
    }

    if (!tipoVehiculo.equals("Bicicleta")) {
        if (placa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar la placa.");
            return;
        }

        if (tipoVehiculo.equals("Moto") && !placa.matches("[A-Z]{3}\\d{3}")) {
            JOptionPane.showMessageDialog(this, "La placa de moto debe tener 3 letras seguidas de 3 números (ej: ABC123).");
            return;
        }

        if ((tipoVehiculo.equals("Auto") || tipoVehiculo.equals("Camioneta")) && !placa.matches("[A-Z]{3}\\d{4}")) {
            JOptionPane.showMessageDialog(this, "La placa debe tener 3 letras seguidas de 4 números (ej: ABC1234).");
            return;
        }

        if (placasRegistradas.contains(placa)) {
            JOptionPane.showMessageDialog(this, "Esta placa ya fue registrada.");
            return;
        }
    } else {
        if (!placa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "La bicicleta no debe tener placa.");
            return;
        }
    }

    registrarOcupacion(puestoSeleccionado, nombre);
    String pinGenerado = generarPinUnico();
    labelpin.setText(pinGenerado);

    try {
                   archivo.getParentFile().mkdirs();
            FileWriter writer = new FileWriter(archivo);
            writer.write("Nombre: " + nombre + "\n");
            writer.write("Apellido: " + apellido + "\n");
            writer.write("Correo: " + correo + "\n");
             writer.write("Cedula: " + cedula + "\n");
            writer.write("Telefono: " + telefono + "\n");
            writer.write("Vehiculo: " + tipoVehiculo + "\n");
            writer.write("Placa: " + placa + "\n");
            writer.write("Puesto: " + puestoSeleccionado + "\n");
            writer.write("FechaIngreso: " + fechaHoy + "\n");
            writer.write("Dias: " + diasPermitidosInt + "\n");
            writer.write("Pin: " + pinGenerado + "\n");
            writer.write("Estado: Activo\n");
            writer.close();

            cedulasRegistradas.add(cedula);
            if (!placa.isEmpty()) placasRegistradas.add(placa);

            JOptionPane.showMessageDialog(this, "Datos guardados correctamente.\nPIN generado: " + pinGenerado);

            String contenidoQR = "Nombre: " + nombre + "\n"
                    + "Apellido: " + apellido + "\n"
                    + "Correo: " + correo + "\n"
                    + "Cédula: " + cedula + "\n"
                    + "Teléfono: " + telefono + "\n"
                    + "Vehículo: " + tipoVehiculo + "\n"
                    + "Placa: " + (placa.isEmpty() ? "N/A" : placa) + "\n"
                    + "Puesto: " + puestoSeleccionado + "\n"
                    + "Pin: " + pinGenerado;

            CodigoQr ventanaQR = new CodigoQr(contenidoQR, cedula,correo);
            ventanaQR.setVisible(true);
            ventanaQR.setLocationRelativeTo(null);

            this.dispose();


    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al guardar el archivo: " + e.getMessage());
    }
    }

    private String generarPinUnico() {
        Random rand = new Random();
        String pin;
        do {
            pin = String.format("%04d", rand.nextInt(10000));
        } while (pinYaExiste(pin));
        pinesUsados.add(pin);
        return pin;
    }

    private boolean pinYaExiste(String pin) {
        File carpeta = new File("archivo");
        if (carpeta.exists()) {
            for (File archivo : Objects.requireNonNull(carpeta.listFiles((dir, name) -> name.endsWith(".txt")))) {
                try (Scanner scanner = new Scanner(archivo)) {
                    while (scanner.hasNextLine()) {
                        if (scanner.nextLine().equals("Pin: " + pin)) return true;
                    }
                } catch (IOException ignored) {}
            }
        }
        return false;
    }

    public void setDatosSeleccionados(String puesto, String tipoVehiculo) {
        this.puestoSeleccionado = puesto;
        this.tipoVehiculo = tipoVehiculo;
        jLabelseleccionar.setText(puesto);
        jLabelvehiculo.setText(tipoVehiculo);
        if (filtroPlaca != null) filtroPlaca.setTipoVehiculo(tipoVehiculo);
    }

    public void registrarOcupacion(String puesto, String nombre) {
        puestosOcupados.put(puesto, nombre);
    }

    public boolean estaOcupado(String puesto) {
        return puestosOcupados.containsKey(puesto);
    }

    public String getNombreOcupante(String puesto) {
        return puestosOcupados.getOrDefault(puesto, "");
    }

public String getEstadoPuesto(String puesto) {
    File carpeta = new File("archivo");
    if (carpeta.exists()) {
        for (File archivo : carpeta.listFiles((dir, name) -> name.endsWith(".txt"))) {
            try (Scanner scanner = new Scanner(archivo)) {
                String archivoPuesto = "";
                String estado = "LIBRE";  // Por defecto
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.startsWith("Puesto: ")) {
                        archivoPuesto = linea.substring(8).trim();
                    } else if (linea.startsWith("Estado: ")) {
                        estado = linea.substring(8).trim();
                    }
                }
                if (archivoPuesto.equals(puesto)) {
                    return estado;
                }
            } catch (IOException ignored) {}
        }
    }
    return "LIBRE"; // ← Evita que retorne null y cause error
}
public LocalDate getFechaIngreso(String puesto) {
    return fechasIngreso.get(puesto);
}

public Integer getDiasPermitidos(String puesto) {
    return diasPermitidos.get(puesto);
}

    public void actualizarColoresBotones() {
         File carpeta = new File("archivo");

    Map<String, String> estadoPorPuesto = new HashMap<>();

    if (carpeta.exists()) {
        for (File archivo : carpeta.listFiles((dir, name) -> name.endsWith(".txt"))) {
            String puesto = "", estado = "";
            try (Scanner scanner = new Scanner(archivo)) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.startsWith("Puesto: ")) {
                        puesto = linea.substring(8).trim();
                    } else if (linea.startsWith("Estado: ")) {
                        estado = linea.substring(8).trim();
                    }
                }
                if (!puesto.isEmpty()) {
                    estadoPorPuesto.put(puesto, estado);
                }
            } catch (IOException e) {
                System.out.println("Error leyendo archivo: " + e.getMessage());
            }
        }
    }

    for (Map.Entry<String, JButton> entry : mapaBotones.entrySet()) {
        String puesto = entry.getKey();
        JButton boton = entry.getValue();

        String estado = estadoPorPuesto.getOrDefault(puesto, "Libre");

        switch (estado) {
            case "Activo" -> boton.setBackground(Color.RED);       
            case "SALIDA" -> boton.setBackground(Color.ORANGE);    
            default -> boton.setBackground(Color.GREEN);           
        }
    }
        
    }

    private void cargarPuestosOcupados() {
        File carpeta = new File("archivo");
        if (carpeta.exists()) {
            for (File archivo : Objects.requireNonNull(carpeta.listFiles((dir, name) -> name.endsWith(".txt")))) {
                try (Scanner scanner = new Scanner(archivo)) {
                    String nombre = "", puesto = "";
                    LocalDate fechaIngreso = null;
                    int dias = 0;

                    while (scanner.hasNextLine()) {
                        String linea = scanner.nextLine();
                        if (linea.startsWith("Nombre: ")) nombre = linea.substring(8).trim();
                        else if (linea.startsWith("Puesto: ")) puesto = linea.substring(8).trim();
                        else if (linea.startsWith("FechaIngreso: ")) fechaIngreso = LocalDate.parse(linea.substring(14).trim());
                        else if (linea.startsWith("Dias: ")) dias = Integer.parseInt(linea.substring(6).trim());
                    }

                    if (!puesto.isEmpty()) {
                        puestosOcupados.put(puesto, nombre);
                        if (fechaIngreso != null) fechasIngreso.put(puesto, fechaIngreso);
                        if (dias > 0) diasPermitidos.put(puesto, dias);
                    }

                } catch (IOException ignored) {}
            }
        }
    }

    private void cargarDatosExistentes() {
        File carpeta = new File("archivo");
        if (carpeta.exists()) {
            for (File archivo : Objects.requireNonNull(carpeta.listFiles((dir, name) -> name.endsWith(".txt")))) {
                try (Scanner scanner = new Scanner(archivo)) {
                    String cedula = "", placa = "";
                    while (scanner.hasNextLine()) {
                        String linea = scanner.nextLine();
                        if (linea.startsWith("Cedula: ")) cedula = linea.substring(8).trim();
                        else if (linea.startsWith("Placa: ")) placa = linea.substring(7).trim();
                    }
                    if (!cedula.isEmpty()) cedulasRegistradas.add(cedula);
                    if (!placa.isEmpty()) placasRegistradas.add(placa);
                } catch (IOException ignored) {}
            }
        }
    }

    // --------------------- Filtros ---------------------

    class FiltroPlacaPorVehiculo extends DocumentFilter {
        private String tipoVehiculo;

        public FiltroPlacaPorVehiculo(String tipoVehiculo) {
            this.tipoVehiculo = tipoVehiculo;
        }

        public void setTipoVehiculo(String tipoVehiculo) {
            this.tipoVehiculo = tipoVehiculo;
        }

        private boolean validar(String texto) {
            return switch (tipoVehiculo) {
                case "Moto" -> texto.matches("[A-Za-z]{0,3}\\d{0,3}") && texto.length() <= 6;
                case "Auto", "Camioneta" -> texto.matches("[A-Za-z]{0,3}\\d{0,4}") && texto.length() <= 7;
                case "Bicicleta" -> texto.isEmpty();
                default -> true;
            };
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            String nuevoTexto = fb.getDocument().getText(0, fb.getDocument().getLength()) + string;
            if (validar(nuevoTexto)) super.insertString(fb, offset, string.toUpperCase(), attr);
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            String nuevoTexto = fb.getDocument().getText(0, fb.getDocument().getLength());
            nuevoTexto = nuevoTexto.substring(0, offset) + text + nuevoTexto.substring(offset + length);
            if (validar(nuevoTexto)) super.replace(fb, offset, length, text.toUpperCase(), attrs);
        }
    }

    class SoloNumerosLimitado extends DocumentFilter {
        private final int maxLength;
        public SoloNumerosLimitado(int maxLength) {
            this.maxLength = maxLength;
        }

        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string.matches("\\d*") && fb.getDocument().getLength() + string.length() <= maxLength) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
            String newText = currentText.substring(0, offset) + text + currentText.substring(offset + length);
            if (newText.matches("\\d*") && newText.length() <= maxLength) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    class SoloLetrasConEspacios extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]*")) {
                super.replace(fb, offset, length, text, attrs);
            }
            }

    
    

   
    }//GEN-LAST:event_jButtonregistroActionPerformed




    
    private void txtcedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcedulaActionPerformed

    private void btRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRegresarActionPerformed
        AdminClie panel1 = new AdminClie();
        this.setVisible(false);
        panel1.setVisible(true);
        
    }//GEN-LAST:event_btRegresarActionPerformed

    private void txtplacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtplacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtplacaActionPerformed

    private void jTextFielddiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFielddiasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFielddiasActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registroauto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registroauto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registroauto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registroauto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroauto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btRegresar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonregistro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelapellido;
    private javax.swing.JLabel jLabelcedula;
    private javax.swing.JLabel jLabeldias;
    private javax.swing.JLabel jLabelnombre;
    private javax.swing.JLabel jLabelseleccionar;
    private javax.swing.JLabel jLabeltelefono;
    private javax.swing.JLabel jLabelvehiculo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextFielddias;
    private javax.swing.JLabel labelpin;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtcedula;
    private javax.swing.JTextField txtcorreo;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtplaca;
    private javax.swing.JTextField txttelefono;
    // End of variables declaration//GEN-END:variables
}
