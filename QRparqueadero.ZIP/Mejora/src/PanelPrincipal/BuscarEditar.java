
package PanelPrincipal;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class BuscarEditar extends javax.swing.JFrame {

  
    public BuscarEditar() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldCedulaeditar = new javax.swing.JTextField();
        jButtonbuscareditar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Ingrese la cedula para editar");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        jTextFieldCedulaeditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCedulaeditarActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldCedulaeditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 250, -1));

        jButtonbuscareditar.setText("Buscar");
        jButtonbuscareditar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonbuscareditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonbuscareditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonbuscareditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldCedulaeditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCedulaeditarActionPerformed

    }//GEN-LAST:event_jTextFieldCedulaeditarActionPerformed

    private void jButtonbuscareditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonbuscareditarActionPerformed
         String cedula = jTextFieldCedulaeditar.getText().trim();

    if (cedula.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor ingrese una cédula.");
        return;
    }

    File carpeta = new File("archivo");
    if (!carpeta.exists()) {
        JOptionPane.showMessageDialog(this, "La carpeta de archivos no existe.");
        return;
    }

    boolean encontrado = false;

    for (File archivo : carpeta.listFiles()) {
        if (archivo.getName().endsWith(".txt")) {
            try (Scanner scanner = new Scanner(archivo)) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    if (linea.equalsIgnoreCase("Cedula: " + cedula)) {
                        encontrado = true;

                        // Si se encuentra, abrir la ventana de edición con ese archivo
                        Editardatos editor = new Editardatos(archivo.getAbsolutePath());
                        editor.setVisible(true);
                        editor.setLocationRelativeTo(null);
                        this.dispose(); // cerrar ventana actual
                        return;
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al leer archivo: " + e.getMessage());
            }
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(this, "No se encontró ningún archivo con esa cédula.");
    }
    }//GEN-LAST:event_jButtonbuscareditarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BuscarEditar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BuscarEditar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BuscarEditar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BuscarEditar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BuscarEditar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonbuscareditar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFieldCedulaeditar;
    // End of variables declaration//GEN-END:variables
}
