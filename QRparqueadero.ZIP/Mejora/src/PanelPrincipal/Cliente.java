
package PanelPrincipal;

public class Cliente extends javax.swing.JFrame {

       private registroauto registro; 

  public Cliente(registroauto registro) {
    this.registro = registro;
    initComponents();
}

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButtonigresopin = new javax.swing.JButton();
        jButtoningresoqr = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButtonpinretirar = new javax.swing.JButton();
        jButtonQR2 = new javax.swing.JButton();
        jLabelregresar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Ingresar Vehiculo");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 20, -1, -1));

        jButtonigresopin.setText("Contraseña de seguridad");
        jButtonigresopin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonigresopinActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonigresopin, new org.netbeans.lib.awtextra.AbsoluteConstraints(67, 68, -1, -1));

        jButtoningresoqr.setText("Escaneo QR");
        jButtoningresoqr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtoningresoqrActionPerformed(evt);
            }
        });
        jPanel1.add(jButtoningresoqr, new org.netbeans.lib.awtextra.AbsoluteConstraints(92, 120, -1, -1));

        jLabel2.setText("Retirar Vehiculo");

        jButtonpinretirar.setText("Contraseña de seguridad");
        jButtonpinretirar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonpinretirarActionPerformed(evt);
            }
        });

        jButtonQR2.setText("Escaneo QR");
        jButtonQR2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonQR2ActionPerformed(evt);
            }
        });

        jLabelregresar.setText("Regresar");
        jLabelregresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelregresarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButtonpinretirar)
                .addGap(67, 67, 67))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jButtonQR2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabelregresar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel2)
                .addGap(29, 29, 29)
                .addComponent(jButtonpinretirar)
                .addGap(18, 18, 18)
                .addComponent(jButtonQR2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addComponent(jLabelregresar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonigresopinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonigresopinActionPerformed
Ingresopin pin2 = new Ingresopin();
pin2.setVisible(true);
pin2.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButtonigresopinActionPerformed

    private void jLabelregresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelregresarMouseClicked
  AdminClie AdminCliente = new AdminClie();
        this.setVisible(false);
        AdminCliente.setVisible(true);    }//GEN-LAST:event_jLabelregresarMouseClicked

    private void jButtonpinretirarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonpinretirarActionPerformed

    }//GEN-LAST:event_jButtonpinretirarActionPerformed

    private void jButtonQR2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonQR2ActionPerformed
    new CamaraQR(registro, CamaraQR.Modo.SALIDA).setVisible(true);


    }//GEN-LAST:event_jButtonQR2ActionPerformed

    private void jButtoningresoqrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtoningresoqrActionPerformed
    new CamaraQR(registro, CamaraQR.Modo.ENTRADA).setVisible(true);

    }//GEN-LAST:event_jButtoningresoqrActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                registroauto reg = new registroauto(); // si no lo tienes aún

           new Cliente(reg).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonQR2;
    private javax.swing.JButton jButtonigresopin;
    private javax.swing.JButton jButtoningresoqr;
    private javax.swing.JButton jButtonpinretirar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelregresar;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
