package PanelPrincipal;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.swing.JOptionPane;

public class RetiroPin extends javax.swing.JFrame {

    private registroauto registro;

    public RetiroPin() {
        initComponents();
        this.registro = new registroauto();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonconfirmar = new javax.swing.JButton();
        jButtonregresar = new javax.swing.JButton();
        jTextFieldretirarpin = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonconfirmar.setText("Confirmar");
        jButtonconfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonconfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonconfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, -1, -1));

        jButtonregresar.setText("Regresar");
        jButtonregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonregresarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        jTextFieldretirarpin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldretirarpinActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldretirarpin, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 200, -1));

        jLabel1.setText("Ingrese pin para retirar vehiculo");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 311, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonconfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonconfirmarActionPerformed
             String pinIngresado = jTextFieldretirarpin.getText().trim();

        if (pinIngresado.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un PIN.");
            return;
        }

        File carpeta = new File("archivo");
        boolean encontrado = false;

        if (carpeta.exists()) {
            for (File archivo : Objects.requireNonNull(carpeta.listFiles((dir, name) -> name.endsWith(".txt")))) {
                List<String> lineas = new ArrayList<>();
                String estadoActual = "";
                String pinArchivo = "";
                String tipoVehiculo = "";
                String puesto = "";
                String diasTexto = "";
                String fechaTexto = "";

                try (Scanner scanner = new Scanner(archivo)) {
                    while (scanner.hasNextLine()) {
                        String linea = scanner.nextLine();
                        if (linea.startsWith("Pin: ")) {
                            pinArchivo = linea.substring(5).trim();
                        } else if (linea.startsWith("Estado: ")) {
                            estadoActual = linea.substring(8).trim();
                        } else if (linea.startsWith("Vehiculo: ")) {
                            tipoVehiculo = linea.substring(10).trim();
                        } else if (linea.startsWith("Puesto: ")) {
                            puesto = linea.substring(8).trim();
                        } else if (linea.startsWith("Dias: ")) {
                            diasTexto = linea.substring(6).trim();
                        } else if (linea.startsWith("Fecha: ")) {
                            fechaTexto = linea.substring(7).trim();
                        }
                        lineas.add(linea);
                    }
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(this, "Error al leer archivo: " + e.getMessage());
                    return;
                }

                if (pinArchivo.equals(pinIngresado)) {
                    encontrado = true;

                    if (!estadoActual.equalsIgnoreCase("Activo")) {
                        JOptionPane.showMessageDialog(this, "Este vehículo no está en estado ACTIVO. No se puede retirar.");
                        return;
                    }

                    String[] opciones = {"Temporalmente", "Definitivamente"};
                    int eleccion = JOptionPane.showOptionDialog(this,
                            "¿Desea retirar el vehículo temporal o definitivamente?",
                            "Confirmar Retiro",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            opciones,
                            opciones[0]);

                    if (eleccion == 0) { // SALIDA TEMPORAL
                        try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
                            for (String linea : lineas) {
                                if (linea.startsWith("Estado: ")) {
                                    writer.println("Estado: SALIDA");
                                } else {
                                    writer.println(linea);
                                }
                            }
                            JOptionPane.showMessageDialog(this, "Vehículo marcado como 'SALIDA' temporal correctamente.");
                        } catch (IOException e) {
                            JOptionPane.showMessageDialog(this, "Error al actualizar el archivo: " + e.getMessage());
                        }
                    } else if (eleccion == 1) { // SALIDA DEFINITIVA
                        try {
                            int dias = Integer.parseInt(diasTexto);
                            double total = dias * 1.5;

                            JOptionPane.showMessageDialog(this, "Total a pagar: $" + String.format("%.2f", total));

                            if (archivo.delete()) {
                                JOptionPane.showMessageDialog(this, "Archivo del cliente eliminado. Retiro definitivo completado.");
                            } else {
                                JOptionPane.showMessageDialog(this, "Error al eliminar el archivo del cliente.");
                            }

                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(this, "Error al procesar retiro definitivo: " + e.getMessage());
                        }
                    }

                    this.dispose();
                    break;
                }
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "PIN no encontrado.");
        }
        

    
    }//GEN-LAST:event_jButtonconfirmarActionPerformed

    private void jButtonregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonregresarActionPerformed
        Cliente cli = new Cliente(registro);
        this.setVisible(false);
        cli.setVisible(true);
    }//GEN-LAST:event_jButtonregresarActionPerformed

    private void jTextFieldretirarpinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldretirarpinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldretirarpinActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RetiroPin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RetiroPin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RetiroPin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RetiroPin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RetiroPin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonconfirmar;
    private javax.swing.JButton jButtonregresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFieldretirarpin;
    // End of variables declaration//GEN-END:variables
}
